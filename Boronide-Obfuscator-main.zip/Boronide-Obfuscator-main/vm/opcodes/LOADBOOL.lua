Stack[|A|]	= (|B| ~= 0);

if (|C| ~= 0) then
    InstrPoint	= InstrPoint + 1;
end;