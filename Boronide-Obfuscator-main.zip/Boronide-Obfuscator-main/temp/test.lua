--[[
	herrtt's obfuscator, v0.2.3
--]]


local WATERMARK, CONST_TABLE, gfenv = nil, nil, nil;
([[herrtts obf]]):gsub('(.*)', function(w)

            local watermark = "dG9iybbhx";
local Shit = "WrqUWj";
            local N_1_ = 5023;
local A_1_ = 2945;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 2048) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 28284;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 3147) * 2;
watermark = w
end;
if (10046 - N_1_) < (A_1_ + 5031) then
N_1_ = ((A_1_ + 5023) * 2);
Shit = w
end;
end;
if N_1_ > (A_1_ - 85452) then
A_1_ = (N_1_ + 10046);
gfenv = getfenv or function() return _ENV end;
end;
end;

            
            local __ENV__ = gfenv();
            local charConst = __ENV__["string"]["\99\104\97\114"](99, 104, 97, 114)
            local string = __ENV__[string[charConst](115, 116, 114, 105, 110, 103)];
            local byte = "YlrkRuRWY";
local char = "OJ5KQsEhXhaJUYV";
local gmatch = "pGnNfpOvRq4V2U";

            local N_1_ = 6483;
local A_1_ = 4881;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 1967) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 33800;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 1789) * 2;
char = __ENV__[string[charConst](115, 116, 114, 105, 110, 103)][charConst];
end;
if (12966 - N_1_) < (A_1_ + 6513) then
N_1_ = ((A_1_ + 6483) * 2);
byte = __ENV__[string[charConst](115, 116, 114, 105, 110, 103)][string[charConst](98, 121, 116, 101)];
end;
end;
if N_1_ > (A_1_ - 92108) then
A_1_ = (N_1_ + 12966);
gmatch = __ENV__[string[charConst](115, 116, 114, 105, 110, 103)][string[charConst](103, 109, 97, 116, 99, 104)];
end;
end;

            CONST_TABLE = {
                [watermark] = 11,
                ['\95' .. char(104, 101, 114, 114, 116, 116, 115, 32, 111, 98, 102) ] = Shit
            }

            CONST_TABLE[string[charConst](95, 120, 88, 89, 90, 51, 121, 56, 57, 121, 95, 49, 51, 108, 54, 73, 90)] = byte;
            CONST_TABLE[string[charConst](95, 120, 90, 48, 95, 88, 56, 56, 90, 51, 79, 105, 111, 57, 89, 55, 105)] = char;
            CONST_TABLE[string[charConst](95, 120, 76, 73, 76, 90, 48, 73, 90, 54, 122, 120, 76, 49, 51, 89, 76)] = gmatch;
            local N_1_ = 1786;
local A_1_ = 492;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 1531) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 13268;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 4432) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 24872;
if (CONST_TABLE[watermark] ~= nil and (#Shit ~= CONST_TABLE[watermark])) then return 0; end;
end;
if N_1_ > (A_1_ - 3572) then
A_1_ = (N_1_ + 3572);
if (char(104, 101, 114, 114, 116, 116, 115, 32, 111, 98, 102) ~= watermark) then return false; end
end;
end;
if (3572 - N_1_) < (A_1_ + 1832) then
N_1_ = ((A_1_ + 1786) * 2);
if (Shit ~= CONST_TABLE['\95' .. watermark]) then return (CONST_TABLE._Q5hAj_hPidfYqhl); end;
end;
end;
if N_1_ > (A_1_ - 28576) then
A_1_ = (N_1_ + 3572);
WATERMARK = watermark
end;
end;


            WATERMARK = watermark;
            CONST_TABLE[watermark] = nil;
        end);
        local char = CONST_TABLE["_xZ0_X88Z3Oio9Y7i"];
        local byte = CONST_TABLE["_xXYZ3y89y_13l6IZ"];
        local gmatch = CONST_TABLE["_xLILZ0IZ6zxL13YL"];
        local string = gfenv()[char(115, 116, 114, 105, 110, 103)];
        local format = string[char(102, 111, 114, 109, 97, 116)];
        local sub = string[char(115, 117, 98)];
        local next = gfenv()[char(110, 101, 120, 116)];
        local concat = gfenv()[char(116, 97, 98, 108, 101)][char(99, 111, 110, 99, 97, 116)];
        local assert = gfenv()[char(97, 115, 115, 101, 114, 116)];
        local pairs = gfenv()[char(112, 97, 105, 114, 115)];
        local len = string[char(108, 101, 110)]
        local rawget = gfenv()[char(114, 97, 119, 103, 101, 116)];
        local unpack = gfenv()[char(117, 110, 112, 97, 99, 107)];


        local charactertable = {}
        local basedictdecompress = {}
        for i = 0, 255 do
            local ic, iic = char(i), char(i, 0)
            charactertable[ic] = iic
            basedictdecompress[iic] = ic
        end

        CONST_TABLE["_xXYZ3y89y_13l6IZ"] = nil;
        CONST_TABLE["_xZ0_X88Z3Oio9Y7i"] = nil;
        CONST_TABLE["_xLILZ0IZ6zxL13YL"] = nil;
        local sub = gfenv()[char(115, 116, 114, 105, 110, 103)][char(115, 117, 98)];
        local constMTableIndex = "_xZ_oO0o0Y63949I";
        
        local domath = function(...) return ... end;
        local wordindex = 0;
        local environment = {(CONST_TABLE._Rsyyd8)}
        
        --// generate this one 2-3 times and randomize the 65536 and 256
            local getCWord = function(str, wordindex, Environment)
                local left, right, front = Environment[(CONST_TABLE._I97TkYbwhYZkX)](str, wordindex, wordindex + 2)
                wordindex = wordindex + 3
                return (front * 65536) + (right * 256) + left
            end
local getAWord = function(len, str, wordindex, Environment)
                len = len or 1
                local word = Environment[(CONST_TABLE._AwMQWuH0)](str, wordindex, domath(wordindex, domath(len, 1, (CONST_TABLE._zTtPXTn)), (CONST_TABLE._Q6zw9QBW5Bq))) --// wordindex + (len - 1)
                wordindex = domath(wordindex, len, (CONST_TABLE._Q6zw9QBW5Bq)) --// wordindex + len
                return word
            end
--// generate this one 4-5 times and randomize the numbers
            local getDWord = function(str, wordindex, Environment)
                local left, right, front, bacl = Environment[(CONST_TABLE._I97TkYbwhYZkX)](str, wordindex, wordindex + 3)
                wordindex = wordindex + 4
                return (back * 16777216) + (front * 65536) + (right * 256) + left;
            end
--// generate this one like 1-3 times but randomize the 256
            local getBWord = function(str, wordindex, Environment)
                local left, right = Environment[(CONST_TABLE._I97TkYbwhYZkX)](str, wordindex, wordindex + 1)
                wordindex = wordindex + 2
                return (right * 256) + left
            end
--// generate this one 5 times and randomize the numbers
            local getQWord = function(str, wordindex, Environment)
                local left, right, front, back, top = Environment[(CONST_TABLE._I97TkYbwhYZkX)](str, wordindex, wordindex + 4)
                wordindex = wordindex + 5
                return (back * 16777216) + (front * 65536) + (right * 256) + left
                + (top * 4294967296);
            end

        --nerd
        -- thanks melancholy

        -- // equality, less than, greater than test
        local function check(val, val2, statement)
            assert(statement, (CONST_TABLE._B6WRrZ2Y))
            if statement == (CONST_TABLE._pN6YHB) then
                return val == val2
            elseif statement == (CONST_TABLE._VgLeqXCHHzmCT) then
                return val < val2
            elseif statement == (CONST_TABLE._DkPZv) then
                return val <= val2
            end
        end
        
        -- // maths stuff
        local function domath(val, val2, statement)
            assert(statement, (CONST_TABLE._B6WRrZ2Y))
            if check(statement, (CONST_TABLE._xU6IjB1Na64nE), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._xU6IjB1Na64nE) then
                return val * val2
            elseif check(statement, (CONST_TABLE._BB4WJVqJDY), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._BB4WJVqJDY) then
                return val / val2
            elseif check(statement, (CONST_TABLE._Q6zw9QBW5Bq), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._Q6zw9QBW5Bq) then
                return val + val2
            elseif check(statement, (CONST_TABLE._zTtPXTn), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._zTtPXTn) then
                return val - val2
            elseif check(statement, (CONST_TABLE._U3V_N8lXzLwxue), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._U3V_N8lXzLwxue) then
                return val % val2
            elseif check(statement, (CONST_TABLE._VQfBm0NrswE), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._VQfBm0NrswE) then
                return val ^ val2
            end
        end
        
        -- // dont know what to call this tbh
        local function reverser(val, statement)
            assert(statement, (CONST_TABLE._B6WRrZ2Y))
            if check(statement, (CONST_TABLE._s_DY7NMBxasKm_), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._s_DY7NMBxasKm_) then
                return -val
            elseif check(statement, (CONST_TABLE._s7R6brIbqwgyH6), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._s7R6brIbqwgyH6) then
                return not val
            elseif check(statement, (CONST_TABLE._q4_EC_r), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._q4_EC_r) then
                return #val
            end
        end
        
        -- // concat stuff
        local function concat(val, val2, statement)
            assert(statement, (CONST_TABLE._B6WRrZ2Y))
            if check(statement, (CONST_TABLE._OmmMb5RMUMG), (CONST_TABLE._pN6YHB)) then --// if statement == (CONST_TABLE._OmmMb5RMUMG) then
                return val .. val2
            elseif check(statement, (CONST_TABLE._fFQFyMxFiGWd), (CONST_TABLE._pN6YHB)) then --// statement == (CONST_TABLE._fFQFyMxFiGWd) then
                return concat(val, val2)
            end
        end
        

        local chartbl = {}
        local XORTable1Fake, BitXOR, XORString1Fake, XORString, XORTable
        local N_1_ = 6567;
local A_1_ = 6286;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 3471) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 40152;

            XORTable1Fake = function(tabl, key)
                local res = "";
                local a = 1
                for i = 1,#tabl do
                    local xored = BitXOR(tabl[i], byte(sub(key, a,a)) )
                    res = res .. chartbl[xored] or xored
                    a = a + 1;
                    if a > #key then
                        a = 1;
                    end
                end
    
                return res
            end;
            
end;
if N_1_ > (A_1_ - 13134) then
A_1_ = (N_1_ + 13134);

            XORString1Fake = function(str, key)
                local res = "";
                local a = 1
                for i = 1,#str do
                    local xored = BitXOR(byte(sub(str, i, i)), byte(sub(key, a,a)) )
                    res = res .. rawget(chartbl, xored) or xored
                    a = a + 1;
                    if a > #key then
                        a = 1
                    end
                end
    
                return res   
            end;
            
end;
end;


        BitXOR = function(a,b) --Bitwise xor
            local p,c=1,0
            while a>0 and b>0 do
                local ra,rb=a%2,b%2
                if ra~=rb then c=c+p end
                a,b,p=(a-ra)/2,(b-rb)/2,p*2
            end
            if a<b then a=b end
            while a>0 do
                local ra=a%2
                if ra>0 then c=c+p end
                a,p=(a-ra)/2,p*2
            end
            return c
        end;

        for i, v in pairs(charactertable) do
            chartbl[byte(i)] = i
        end

        local N_1_ = 2757;
local A_1_ = 4718;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 9436;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 4703) * 2;

        XORTable = function(tabl, key)
            local res = "";
            local a = 1
            for i = 1,#tabl do
                local xored = BitXOR(tabl[i], byte(sub(key, a,a)) )
                res = res .. chartbl[xored] or xored
                a = a + 1;
                if a > #key then
                    a = 1;
                end
            end

            return res
        end;
        
end;
if (5514 - N_1_) < (A_1_ + 2768) then
N_1_ = ((A_1_ + 2757) * 2);

        XORString = function(str, key)
            local res = "";
            local a = 1
            for i = 1,#str do
                local xored = BitXOR(byte(sub(str, i, i)), byte(sub(key, a,a)) )
                res = res .. rawget(chartbl, xored) or xored
                a = a + 1;
                if a > #key then
                    a = 1
                end
            end

            return res   
        end;
        
end;
end;

        
        local NumberTable = { {}, {} }
        local TrackNumberTable = 1
        for i = 1, 255 do
            if i >= 112 then
                NumberTable[2][TrackNumberTable] = i
            TrackNumberTable = TrackNumberTable + 1
            else
                NumberTable[1][i] = i
            end
        end

        local characters = char(unpack(NumberTable[1])) .. char(unpack(NumberTable[2]))

        local xorPrimaryKey, XORStringPrim, xorDecodeckey, XORStringSec, xorSecondaryKey, XORTableSec, XORStringPrim1;
        xorSecondaryKey = XORTable({58, 22, 59, 22, 49, 33, 54, 54, 8, 41, 26}, "\104\80\121\117\103\81\100\120\122\66\117\113");

        local N_1_ = 3381;
local A_1_ = 1682;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 2422) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 23212;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 4829) * 2;
XORTableSec = function(...)
                return XORTable(..., xorSecondaryKey)
            end;
end;
if (6762 - N_1_) < (A_1_ + 3393) then
N_1_ = ((A_1_ + 3381) * 2);
XORStringPrim = function(a, ...)
                return XORString(a, xorPrimaryKey, ...)
            end;
end;
end;
if N_1_ > (A_1_ - 79204) then
A_1_ = (N_1_ + 6762);
XORStringSec = function(a, ...)
                return XORString(a, xorSecondaryKey, ...)
            end;
end;
end;


        xorPrimaryKey = XORTable({15, 24, 62, 37, 29, 52, 38, 34, 20, 26}, "\104\80\121\117\103\81\100\120\122\66\117\113");
        xorDecodeckey = XORTable({50, 9, 12, 36, 41, 62, 54, 59, 42, 3, 57}, "\104\80\121\117\103\81\100\120\122\66\117\113");
        local _1 = byte(char(1));
        CONST_TABLE["_xz8L3OX7Y34X07ZoX"] = function(str, key)
            local res = char();
            local a = _1;
            for i = _1, #str do
                local xored = BitXOR( byte(sub(str, i, i)), byte(sub(key, a,a)) );
                res = format(((CONST_TABLE._0TKnbA7IzuKVW)), res, rawget(chartbl, xored) or xored);
                a = a + _1;
                a = (a > #key and _1) or a;
            end;
            return res;
        end;
        local xorStrS1 = CONST_TABLE[XORTableSec({13,62,56,91,26,67,29,22,69,50,92,102,30,114,84,12,31,10})];
        

return (function(__ARG__) 
            local Environment, watermark, amountOfArgs;
            amountOfArgs = (amountOfArgs or 0);
            for i,v in pairs(__ARG__) do
                amountOfArgs = (amountOfArgs or 0) + 1
            end

            if (amountOfArgs < 2) then
                return ("GuSy4jnNt")
            end

            local N_1_ = 2453;
local A_1_ = 2498;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 4996;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 2717) * 2;
watermark = __ARG__[2];
end;
if (4906 - N_1_) < (A_1_ + 2488) then
N_1_ = ((A_1_ + 2453) * 2);
Environment = __ARG__[1];
end;
end;

            CONST_TABLE = { };
            do
                local setmetatable = gfenv()[XORStringSec("\33\35\54\14\51\4\51\58\19\9\3\55")];
                if (setmetatable ~= nil) then -- just incase they got some shit lua version
                    CONST_TABLE[XORStringSec("\13\62\24\60\57\63\98\33\66\50\89\97\127\118\90\31")] = setmetatable({
                        [-113.55425225014625] = -9.79232559077387;
[-7.762891547896544] = 98.18816062745111;
                    }, {
                        [XORStringSec("\13\25\54\12\37\4\32\39\28\12")] = function(a, b)
                            return (function()
                                while true do
                                    CONST_TABLE = CONST_TABLE or nil;
                                    if (CONST_TABLE ~= nil and CONST_TABLE[1] ~= nil) then
                                        break
                                    else
                                        CONST_TABLE["\89\107\72\78\90\87\54\113\79\77\115\117\85\56\53\88\102\83\67\54\120"] = "\72\89\48\116\56\110\78\66\114";
                                    end
                                end;
                                
                                return "\114\82\52\100\52\65\79\111\104\103\83\84\120\54\72\120\111\103\113\74\52\111\72\113\83\85\87\110";
                            end)();
                        end;
                    });
                    CONST_TABLE[1] = CONST_TABLE[constMTableIndex];
                end;
                
do
CONST_TABLE[XORStringSec("\13\42\115\37\61\66")] = XORString("\42\63\118\47\9\60\43\39\71\88", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\60\122\51\51\1\17\34\26\45\35\22\113\52")] = XORString("\51", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\23\48\41\28\19\62\6\4\38\94\25\18\4")] = XORString("\37\39\35", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\42\5\26\50\58\30\34\48\8\6")] = XORString("\42\25\45\83\58\70\61\23\71\90", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\39\41\19\61\64\51\23\34\62\21\48\43")] = XORString("\42\30\122\81\111\41\62\20\71\36\92\98\25", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\33\16\47\23\67")] = XORString("\13\25\50\17\57\4\61\17\45", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\117\27\16\50\65\3\22")] = XORString("\42\9\59\80\25\60\59\23\30\95\95\10\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\14\37\55\52\21\11")] = XORString("\38\39\32\15\51", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\15\16\50\26\42\38\56\74\93\58")] = XORString("\60", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\43\54\84\34\26")] = XORString("\33\35\46\6\53\4", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\34\55\82\53\2\102\17\54\32\46\96\45\42")] = XORString("\42\40\23\42\100\25\39\27\29\92\95\98", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\63\23\50\19\53\3\30\51\63")] = XORString("\14\118", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\117\1\86\2\9\16\54\56\39")] = XORString("\42\15\26\91\97\28\8\22\69\93", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\44\8\45\100\61\106\9")] = XORString("\42\42\46\83\100\64\10\55\30\17", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\4\58\6\100\41\60\123\30\12")] = XORString("\42\41\14\26\99\70\100\22\10\92\0\29\41", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\10\90\111\24\38\118\38\37\4\34\7\15")] = XORString("\42\62\119\59\63\66\43\122\59\18\94\97\118", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\19\113\53\9\62\106\34\42\17\35\37\62\55\6")] = XORString("\46\11\13\39\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\63\117\41\30\53\28")] = XORString("\60\51\47\1\51\2", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\58\21\4\1\2\44\17\37\36\0\2\29\41\16")] = XORString("\46\7\6\39\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\39\50\46\24\39\97\26\32\28")] = XORString("\104\110\103\7\124\89\104", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\20\49\26\47\20\106")] = XORString("", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\31\48\54\36\58\42\58\67\56\57\31\19\46\47")] = XORString("\42\15\26\91\97\28\8\22\69\93", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\15\123\84\2\27\11\44\5\3\54\8\45\26")] = XORString("\46\21\54\17\63\30\53\44\11\31\10\46", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\62\23\85\31\26\16\127\60\10\89\102\40\7")] = XORString("\46\11\23\47\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\33\49\14\21\28\24\31\20\41\91\16\47\122\44")] = XORString("\42\30\29\91\14\37\107\22\61\88\55\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\49\29\59\61\49\98\62\34\15")] = XORString("\46\5\13\45\21\49\6\29\38\57\38\28\1\62", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\54\15\63\4\42\0")] = XORString("\33\50\48\10\56\23", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\9\47\14\27\18\103\28\63\62\34\21")] = XORString("\46\5\13\45\21\49\6\29\38\57\38\28\1\62", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\0\19\37\14\61\53\29\53\9\2\24\1\42\16\110")] = XORString("\42\9\113\84\98\71\10\127\11\88", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\34\46\5\12\4\4\20\7\25\89")] = XORString("\42\41\24\86\98\10\62\119\43\18\86\98\62", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\43\119\46\36\35\13\61\59\14\27\21\28\10\40")] = XORString("\7\4\4\43\23\21\19\40\4\62\1\36\30\45\42\60", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\60\54\47\1\49\2\118\1\33\24\63\47\27\27\53")] = XORString("\10", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\40\122\81\28\20\10\3")] = XORString("\127", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\19\32\41\46\60\11\59\61")] = XORString("\42\25\11\86\26\9\27\55\43\89", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\118\11\44\23\8\13\30\52\37\31\11\14")] = XORString("\33\50\48\10\56\23", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\40\10\11\0\21\8\7\75\44\92\1\17")] = XORString("\46\10\22\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\5\45\52\32\30\61\27\55\57")] = XORString("\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\52\113\54\4\21\35\57\68\60\26\20\49")] = XORString("\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\122\52\26\71\38\24\54\41\56\55\53\43")] = XORString("\42\28\118\87\111\57\62\119\64\95", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\117\49\96\18\32\7\16\26\24\53\63\10\85")] = XORString("\46\8\13\55\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\7\35\60\96\58\6\32\62\90\25\32\0\32")] = XORString("\33", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\46\4\54\24\67\57\8\10\44\28\60")] = XORString("\19\42\48\6\55\20\43\110\0\10\1\114\110\112\74\119", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\63\17\5\26\19\101\122\2\25\88\51\116")] = XORString("\42\15\46\81\98\40\102\127\66\94", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\39\6\42\51\61\17\127\31")] = XORString("\42\12\11\91\35\65\10\39\39\2\93", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\1\40\85\96\50\37\42\19\14\93\57\126\3")] = XORString("\42\53\10\49\16\31\21\35\3", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\37\24\10\55\42\37\44")] = XORString("\1\19\18\38\4\47\29\30", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\116\11\25\21\55\96\35\65")] = XORString("\59\40\52\2\58\25\54\110\27\5\11\55\62\99", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\31\113\52\15\5\106")] = XORString("\30\49\53\18\19\37\6\56\42\17\63\30\53\5\27\21", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\52\47\7\42\39\22\6\88\27\7\117\20\58")] = XORString("\34\63\19\57\5\7\26\15\19\91", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\29\39\15\71\28\3\48\19\14\33\13\47\60")] = XORString("\46\19\12\46\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\23\116\25\33\73\3\12\37\94\45\35")] = XORString("\46\7\6\39\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\32\18\0\35\72")] = XORString("\42\9\45\10\47\71\107\127\29\89", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\46\19\1\0\37")] = XORString("\29\14\44\37\47\51\20\57\16\26\2\1\23\26\53\28", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\19\123\22\61\56\39\30\45\28\56")] = XORString("\48", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\42\14\60\61\38\123\19")] = XORString("\42\126\118\52\57\71\5\127\29\82", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\44\43\57\44\22\21\42\2\0\25\97\28\4\11\49")] = XORString("\42\47\14\12\47\66\99\7\29\83\91\106\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\60\47\45\44\7\53\57\57\82\60\53\50\35\59\46")] = XORString("\42\9\45\10\47\71\107\127\29\89", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\53\11\41\101\23")] = XORString("\42\15\46\81\98\40\102\127\66\94", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\36\13\53\9\68\11\28\2\8\30\23\31\46\6")] = XORString("\113", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\49\23\46\6\29\38\3\28\2")] = XORString("\61\41\35", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\52\39\18\5\36\100\43\29\33\36\60\13\24\38")] = XORString("\42\42\115\85\101\31\102\125\42\82\24", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\4\17\46\110\0\21")] = XORString("\42\31\45\10\31\67\98\121\68\36\38\62\115", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\62\118\8\102\2")] = XORString("\46\11\23\47\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\14\122\0\63\38\10\38")] = XORString("\42\34\23\44\1\70\7\124\45\92\48", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\0\26\81\50\47\3\15")] = XORString("\42\16\114\20\25\67\61\122\75\93\58", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\3\44\1\51\29\28\123\62\7\28")] = XORString("\13\25\43\13\50\21\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\53\53\14\6\56")] = XORString("\51\36\33\7\51\22\53", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\21\35\84\2\35\60\42\0\90\31\49")] = XORString("\1\19\18\38\4\47\29\30", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\41\51\12\6")] = XORString("\46\10\7\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\32\4\50\16\9\31\54\52\2\40\5\34")] = XORString("\46\5\13\45\21\49\6\26\51\41\35\23\58", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\8\46\43\20\37\33\61\26\49\91")] = XORString("\42\9\113\84\98\71\10\127\11\88", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\31\32\19\17\72\26")] = XORString("\13\62\14\57\98\28\99\22\65\18\94", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\43\55\32\46\61\28\60\6\52\2\60\118")] = XORString("\29\4", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\54\115\85\50\63\0")] = XORString("\42\25\11\86\26\9\27\55\43\89", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\32\58\10\23\35\32\47\39\29")] = XORString("\106\104\117\85\100\64\101\119\69\93\86\96\127\116\85\97\67", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\55\118\60\19\51\13\60")] = XORString("\46\10\7\45\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\8\40\58\26\51\52\56")] = XORString("\46\21\23\33\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\16\19\5\20\29\98\0\0\24\24\23")] = XORString("\46\22\13\52\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\7\53\46\7\39\39\6\66")] = XORString("\46\21\54\17\63\30\53\61\7\9\19", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\47\13\6\30\59\1\61\25\63\28\54\45\123")] = XORString("\42\21\115\33\26\60\99\124\7", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\10\35\45\39\21")] = XORString("\42\22\58\84\111\69\103\125\71\19\87", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\23\119\11\23\26\13\38\34\2\11\52\31\51\11\58")] = XORString("", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\116\19\16\28\22\4\40\65\18")] = XORString("\42\30\114\82\103\71\98\124\8\36\38\27\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\13\47\49\59\29\2")] = XORString("\42\63\118\47\9\60\43\39\71\88", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\21\38\16\6\18\48\29\6\46\32\4\30\37\25\46")] = XORString("\42\60\112\10\46\9\101\20\75\39", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\30\35\57\57\67\31\8\65\47\94\34")] = XORString("\13\25\33\2\58\28", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\9\24\55\31\3\58\31\23\49\6\16\41")] = XORString("\46\19\12\46\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\54\26\91\60\3\98\26\30\12\63\42\17\20")] = XORString("\42\42\46\83\100\64\10\55\30\17", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\5\9\11\52\8\17")] = XORString("\42\28\118\87\111\57\62\119\64\95", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\30\47\5\15\63")] = XORString("\42\30\115\90\103\72\98\126\29\92\38\101\117", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\4\0\87\1\58\4\63\56\47\54")] = XORString("\46\2\11\53\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\11\32\27\26\39\56\13\67\30\13\7\31\37\86\9")] = XORString("\8", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\49\54\57\50\22\22\7\64\60\6\13\62\8\59")] = XORString("\42\62\115\81\12\60\27\22\59\17\89\107\112", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\60\22\23\6\40\6\32")] = XORString("\46\21\23\33\42", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\16\37\47\51\1\10\13\58\35\21\63\5\22")] = XORString("\46\10\22\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\36\116\40\33\31\35\3\8\6\2\63")] = XORString("\13\25\50\17\57\4\61\17\45", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\35\21\6\21\27\32\45\0\30\26\101\45\13")] = XORString("\13\25\44\6\33\25\60\42\23\19", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\28\48\10\62\56\26\54\22\15\95")] = XORString("\19\42\48\6\55\20\43\110\0\10\1\114\110\115\74\119", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\53\12\56\10\33\20\68\49\94\52\119\15\26\96")] = XORString("\42\116\29\54\110\66\7\125\64\30", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\16\116\34\56\73\17\121")] = XORString("\42\28\10\54\24\17\60\127\29", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\4\116\52\4\2\8\124\43")] = XORString("\54\43\98\23\62\25\33\110\6\4\79\26\35\48\17\34\4\114\33\0\75\34\55\42\35\13\53\24\61\34\11", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\5\3\4\6\62\11\118\4")] = XORString("\26\35\48\17\34\4\114\1\16\13\26\33\37\35\23\57\2", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\54\12\85\15\56\16")] = XORString("\46\3\19\31", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\4\43\36\53\37\22\30\68\58\6\6\55")] = XORString("\61\51\18\25\60\53\5\44\0\1\27\60\62\6\7\53", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\17\9\84\21\35\2\119\7\26\60\52\9")] = XORString("\38\39\32\15\51", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\118\22\40\56\18\19\121\59\17\26\25\16\21")] = XORString("\119\53\103\16", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\52\45\10\38\27\7\38\28\9\91\3\127\39")] = XORString("\13\62\56\91\26\67\29\22\69\50\92\102\30\114\84\12\31\10", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\21\50\53\27\5\56\27\1")] = XORString("\111\120", xorSecondaryKey);
CONST_TABLE[XORStringSec("\13\2\115\43\30\62\10\12\58")] = XORString("\43\47\39\15\50", xorSecondaryKey);
end;
            end;CONST_TABLE[(CONST_TABLE._roipkUhnb4Q9e)] = xorStrS1;
--START_ENV_LOAD
local coroutine = gfenv()[XORTableSec({49, 41, 48, 12, 35, 4, 59, 32, 23})];
local select = gfenv()[XORTableSec({33, 35, 46, 6, 53, 4})];
local setraw = gfenv()[XORTableSec({33, 35, 54, 17, 55, 7})];
local error = gfenv()[XORTableSec({55, 52, 48, 12, 36})];
local type = gfenv()[XORTableSec({38, 63, 50, 6})];
local pairs = gfenv()[XORTableSec({34, 39, 43, 17, 37})];
local setmetatable = gfenv()[XORTableSec({33, 35, 54, 14, 51, 4, 51, 58, 19, 9, 3, 55})];
local unpack = gfenv()[XORTableSec({39, 40, 50, 2, 53, 27})];
local tonumber = gfenv()[XORTableSec({38, 41, 44, 22, 59, 18, 55, 60})];
local print = gfenv()[XORTableSec({34, 52, 43, 13, 34})];
local getmetatable = gfenv()[XORTableSec({53, 35, 54, 14, 51, 4, 51, 58, 19, 9, 3, 55})];
local tostring = gfenv()[XORTableSec({38, 41, 49, 23, 36, 25, 60, 41})];
local pcall = gfenv()[XORTableSec({34, 37, 35, 15, 58})];
local rawget = gfenv()[XORTableSec({32, 39, 53, 4, 51, 4})];
local assert = gfenv()[XORTableSec({51, 53, 49, 6, 36, 4})];
local string = gfenv()[XORTableSec({33, 50, 48, 10, 56, 23})];
local table = gfenv()[XORTableSec({38, 39, 32, 15, 51})];
local xorStr = CONST_TABLE["\95\120\122\56\76\51\79\88\55\89\51\52\88\48\55\90\111\88"];
--END_ENV_LOAD
local cyield = coroutine[(CONST_TABLE._D1HHNXBH)];
local function whatLineErr(...)
    local _, str = ...
    local Matched = gmatch(tostring(str), (CONST_TABLE._apMNW3TRw))()
    return tonumber(Matched)
end;

local StartLine = whatLineErr(pcall(function() local a = (CONST_TABLE._z8PeqClhFLD7v) ^ 1 end));
local print = print;
local function _Returns(...)
    return select((CONST_TABLE._bOV_4YRpcqEYle), ...), {...};
end;


        local xiZ73Oo60o = "\0\9xZHUNan1ox\0\0\0\203\255\1\0\1\0\0\0\0\1\0\0\0\0\9xS1BLL12ux\0\0\0\203\255\1\0\1\0\0\0\0\2\0\0\0\0\16ouPzjEWbrjtnxDdcs\0\0\0\0\0\3\0\0\0\0\9xsHRFoGmqn\0\0\0\0\0\4\0\0\0\0\16LwwqEUTvXzPLsGxCs\0\0\0\0\0\5\0\0\0\0\11xV0wO3o496Ub\0\0\0\1\0\0\0\5\0\0\0\0\6\0\0\0\0\11xPx795535x8b\0\1\0\0\0\0\0\65\64\0\0\0\7\0\0\0\0\11xdUOW6U2_7_a\0\0\0\2\0\0\0\1\0\0\28\64\0\1\0\8\0\0\0\0\11xJI8u1XiUi2b\0\0\0\0\0\0\0\36\0\0\0\0\9\0\0\0\0\16UBFHAeAfvUnvXoIjs\0\0\0\0\0\10\0\0\0\0\10x2_U82U32ua\0\1\0\0\0\0\0\0\0\0\64\0\0\0\0\11\0\0\0\1\8a\0\1\0\1\0\0\0\1\0\0\92\64\128\0\0\0\10x84Wo7W1o9a\1y\0\0\0\0\0\0\0\0\23\0\0\0\0\12\0\0\0\0\12xnUI2iuUo700x\0\0\0\3\0\2\0\22\128\0\128\0\13\0\0\0\0\16OHnFyCFwbqmSQXVJs\0\0\0\0\0\14\0\0\0\1\6b\0\1\0\1\0\0\0\69\0\0\0\0\1\7b\0\2\0\6\0\0\0\129\128\0\0\0\1\8a\0\1\0\2\0\0\0\1\0\0\92\64\0\1\0\0\12xX_8XU9XO3Xxa\0\0\0\1\0\0\0\0\0\0\30\0\128\0\0\15\0\0\0\2";
        

        if (CONST_TABLE[constMTableIndex] == nil) then
            return (function()
                while print ~= gfenv do
                    WATERMARK = sub(WATERMARK, 1, #WATERMARK - 1) .. (CONST_TABLE._fxiASraUv);
                end
            end)()
        end;

        -- // integrity check character table
        local function integritycheckchartbl()
            if reverser(check(getmetatable(chartbl), nil, (CONST_TABLE._pN6YHB)), (CONST_TABLE._s7R6brIbqwgyH6)) then -- // if getmetatable(chartable) ~= nil then
                return cyield()
            end
        end

        local function new(signature, size_or_C, chunk_or_upvals, env, uvals)
            local Upvalues;
local isClosure = false;
local ran;
local xeZEBzJI4P = (CONST_TABLE._ztLWAP8sJwmiYxc);
local Env;
local Chunk;
for _ in integritycheckchartbl do break end;
local current;
local ProtoLen;
local size_constinst;
local Lupvals;
local xJbMDeEr9 = (CONST_TABLE._muCxMNrt_mn0);
local InstLen;
local ConstLen;
local last;

            if ((signature ~= 0 and size_or_C ~= (CONST_TABLE._aDIeMC1m)) and signature ~= (CONST_TABLE._CAgPNY8v)) then
                while (signature ~= 0) do
                    size_or_C = (CONST_TABLE._MbxLWjC1ubUYg5_);
                end;
            elseif (signature == 0 and size_or_C == (CONST_TABLE._aDIeMC1m)) then
                isClosure = true;
            end;

            local ctable = {}
            for i = 1, domath(64, 4, (CONST_TABLE._x4k0r)) do
                ctable[i] = char(domath(i, 1, (CONST_TABLE._NjYLCfv)))
            end

            local XORString1
            local xorPrimaryKey1 = (function(a, ...) 
                return a and xorPrimaryKey
            end)((CONST_TABLE._DvLQZuXt3tU3VY))
            local res = concat((CONST_TABLE._Rsyyd8), char(), (CONST_TABLE._w_XkA0pPd));
            local N_1_ = 5872;
local A_1_ = 6184;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 12368;
Chunk = isClosure and (chunk_or_upvals) or ({});
end;

            local N_1_ = 2461;
local A_1_ = 773;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 3404) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 23460;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 2549) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 20040;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 2804) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 21060;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 1669) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 16520;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 640) * 2;
Chunk[(CONST_TABLE._D8WL7tVDBWesi)] = isClosure and (Chunk[(CONST_TABLE._D8WL7tVDBWesi)]) or (chunk_or_upvals);
end;
if (4922 - N_1_) < (A_1_ + 2481) then
N_1_ = ((A_1_ + 2461) * 2);
ProtoLen = (0);
end;
end;
if N_1_ > (A_1_ - 34652) then
A_1_ = (N_1_ + 4922);
size_constinst = isClosure and ({}) or (size_or_C)
end;
end;
if (34652 - N_1_) < (A_1_ + 17358) then
N_1_ = ((A_1_ + 2461) * 2);
InstLen = isClosure and (Chunk[(CONST_TABLE._KmRmmP)][-1]) or (1);
end;
end;
if N_1_ > (A_1_ - 98836) then
A_1_ = (N_1_ + 4922);
ConstLen = isClosure and (Chunk[(CONST_TABLE._pX8js0TlgPxWV)][-1]) or (0);
end;
end;
if (98836 - N_1_) < (A_1_ + 49442) then
N_1_ = ((A_1_ + 2461) * 2);
Upvalues = isClosure and uvals;
end;
end;
if N_1_ > (A_1_ - 227204) then
A_1_ = (N_1_ + 4922);
Lupvals = {}
end;
end;
if (227204 - N_1_) < (A_1_ + 113629) then
N_1_ = ((A_1_ + 2461) * 2);
Env = (isClosure == true and env) or (isClosure == false and uvals or gfenv()) or {};
end;
end;
if N_1_ > (A_1_ - 483940) then
A_1_ = (N_1_ + 4922);
ran = false;
end;
end;


            local N_1_ = 3354;
local A_1_ = 5366;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 10732;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 4951) * 2;
XORString1 = function(str, key)
                    local res1 = res
                    local a = reverser(-1, (CONST_TABLE._OZTIshQeZiBo))
                    for i = 1, len(str) do
                        local xored = BitXOR(byte(sub(str, i, i)), byte(sub(key, a,a)) )
                        res1 = concat(res1, sub(characters, xored, xored) or xored, (CONST_TABLE._w_XkA0pPd));
                        a = check(len(key), a + 1, (CONST_TABLE._nHhVeZI9G3SW)) and 1 or domath(a, 1, (CONST_TABLE._sxvRqPbcNKRD_JF));
                    end

                    return res1
                end;
end;
if (6708 - N_1_) < (A_1_ + 3403) then
N_1_ = ((A_1_ + 3354) * 2);
XORStringPrim1 = function(a, ...)
                    return XORString1(a, xorPrimaryKey1, ...);
                end;
end;
end;

            

            local Metamethods_ = {
[(CONST_TABLE._XaZo3MF3D1p)] = function(self, arg, A, B, C, D)
if (isClosure ~= true and ran) then
    return error((CONST_TABLE._ZrihHHxdd0))
end
if (current == (CONST_TABLE._sIJ3g)) then
    if (last) then
        local N_1_ = 4357;
local A_1_ = 6854;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 13708;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 4536) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 35572;

            local Inst = { [(CONST_TABLE._3C5TyBxJL)] = last };
            local N_1_ = 3214;
local A_1_ = 2925;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 1250) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 17856;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 3030) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 24976;
while (N_1_ > (A_1_ - 12)) do
A_1_ = (N_1_ + 3830) * 2;
Inst[2] = arg[2];
end;
if (6428 - N_1_) < (A_1_ + 3259) then
N_1_ = ((A_1_ + 3214) * 2);
Inst[(CONST_TABLE._Sa7TSndr1pc)] = false;
end;
end;
if N_1_ > (A_1_ - 69208) then
A_1_ = (N_1_ + 6428);
Inst[1] = arg[1];
end;
end;
if (69208 - N_1_) < (A_1_ + 34629) then
N_1_ = ((A_1_ + 3214) * 2);
Chunk[(CONST_TABLE._KmRmmP)][InstLen] = Inst;
end;
end;
if N_1_ > (A_1_ - 176984) then
A_1_ = (N_1_ + 6428);
Inst[3] = arg[3];
end;
end;

            
end;
if N_1_ > (A_1_ - 8714) then
A_1_ = (N_1_ + 8714);
InstLen = InstLen + 1;
end;
end;
if (8714 - N_1_) < (A_1_ + 4377) then
N_1_ = ((A_1_ + 4357) * 2);
last = nil;
end;
end;

    else
        local N_1_ = 5498;
local A_1_ = 4675;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 2391) * 2;
last = arg
end;

    end
elseif (current == (CONST_TABLE._UbJxLYuO)) then
    local IDX;
    local N_1_ = 3506;
local A_1_ = 3674;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 7348;
IDX = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][ConstLen - 1];
end;

    if (arg == nil and type(IDX) == (CONST_TABLE._D4hzgZCl_JMML)) then
        local N_1_ = 2044;
local A_1_ = 608;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 1266) * 2;
Chunk[(CONST_TABLE._pX8js0TlgPxWV)][ConstLen - 1] = { XORStringSec(IDX) };
end;

    elseif (type(arg) == (CONST_TABLE._HgTbeY) and arg[(CONST_TABLE._YbpG8H)] == true) then
        local N_1_ = 6537;
local A_1_ = 5509;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 4805) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 45368;
Chunk[(CONST_TABLE._pX8js0TlgPxWV)][ConstLen] = arg;
end;
if N_1_ > (A_1_ - 13074) then
A_1_ = (N_1_ + 13074);
ConstLen = ConstLen + 1;
end;
end;

    elseif (type(arg) == (CONST_TABLE._HgTbeY)) then
        local N_1_ = 5893;
local A_1_ = 685;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 4592) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 41940;
Chunk[(CONST_TABLE._pX8js0TlgPxWV)][ConstLen] = arg[1] or nil;
end;
if N_1_ > (A_1_ - 11786) then
A_1_ = (N_1_ + 11786);
ConstLen = ConstLen + 1;
end;
end;

    else
        local N_1_ = 1877;
local A_1_ = 2123;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 4246;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 3290) * 2;
Chunk[(CONST_TABLE._pX8js0TlgPxWV)][ConstLen] = arg;
end;
if (3754 - N_1_) < (A_1_ + 1901) then
N_1_ = ((A_1_ + 1877) * 2);
ConstLen = ConstLen + 1;
end;
end;

    end
elseif (current == (CONST_TABLE._gRLA3)) then
    local fix;
    fix = function(whatfix)
        local const = {};
        local constL = 0;
        for i = 1, #whatfix[(CONST_TABLE._jJN2M8G)] do
            local v = whatfix[(CONST_TABLE._jJN2M8G)][i]
            if (type(v) == (CONST_TABLE._HgTbeY)) then
                integritycheckchartbl()
                const[constL] = {
                    XORStringSec(v[1])
                };
                constL = constL + 1
            else
                const[constL] = v
                constL = constL + 1
            end;
        end;
        const[-1] = constL
        whatfix[(CONST_TABLE._pX8js0TlgPxWV)] = const;
        --
        local inst = {};
        local instL = 1;
        for i = 1, #whatfix[(CONST_TABLE._l1Fk2)] do
            local v = whatfix[(CONST_TABLE._l1Fk2)][i]
            inst[instL] = v
            instL = instL + 1
        end
        inst[-1] = instL
        whatfix[(CONST_TABLE._KmRmmP)] = inst
        --
        local proto = {};
        local protoL = 0;
        for i = 1, #whatfix[(CONST_TABLE._fPcu8)] do
            proto[protoL] = fix(whatfix[(CONST_TABLE._fPcu8)][i])
            protoL = protoL + 1
        end
        whatfix[(CONST_TABLE._fPcu8)] = proto
        whatfix[(CONST_TABLE._fPcu8)][-1] = protoL

        return whatfix
    end
    local arg1 = fix(arg)
    Chunk[(CONST_TABLE._fPcu8)][ProtoLen] = arg1;
    ProtoLen = ProtoLen + 1;
elseif (current == (CONST_TABLE._SdsPbbStEOVXgzx)) then
    while (arg > -1) do
        Chunk[A] = Chunk[A] or {};
        Chunk[B] = Chunk[B] or {};
        Chunk[C] = Chunk[C] or {};
        Chunk[(CONST_TABLE._FQFXMgSGbmJGhs8)] = Chunk[(CONST_TABLE._FQFXMgSGbmJGhs8)] or D;
        arg = (arg * -1) - (50);
    end
end
return self;
end;
[(CONST_TABLE._EnbemN5Lls)] = function(self, index)
    if (isClosure ~= true and ran) then
        local N_1_ = 5356;
local A_1_ = 1570;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 3309) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 34660;
 while (1 == 1 and ran == (#Chunk > -1)) do Chunk[index] = (CONST_TABLE._yUQEEQPAT) end;
end;
if N_1_ > (A_1_ - 10712) then
A_1_ = (N_1_ + 10712);
return;
end;
end;

    elseif (Chunk == nil) then
        Chunk = {}
    end;

    local N_1_ = 6861;
local A_1_ = 1752;
while (N_1_ > (A_1_ - 10)) do
A_1_ = (N_1_ + 1785) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 34584;
while (N_1_ > (A_1_ - 11)) do
A_1_ = (N_1_ + 2726) * 2;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 38348;
if (index == (CONST_TABLE._sIJ3g)) then current = index; end;
end;
if N_1_ > (A_1_ - 13722) then
A_1_ = (N_1_ + 13722);
if (index == (CONST_TABLE._gRLA3)) then current = index; end;
end;
end;
if (13722 - N_1_) < (A_1_ + 6861) then
N_1_ = ((A_1_ + 6861) * 2);
if (index == (CONST_TABLE._UbJxLYuO)) then current = index; end;
end;
end;
if N_1_ > (A_1_ - 109776) then
A_1_ = (N_1_ + 13722);
if (index == (CONST_TABLE._SdsPbbStEOVXgzx)) then current = index; end;
end;
end;


    if (index ~= (CONST_TABLE._sIJ3g) and index ~= (CONST_TABLE._UbJxLYuO) and index ~= (CONST_TABLE._SdsPbbStEOVXgzx) and index ~= (CONST_TABLE._gRLA3)) then
        local N_1_ = 2651;
local A_1_ = 4532;
while (N_1_ < A_1_) do
A_1_ = N_1_ - 9064;
return error((CONST_TABLE._2IzCG2m3));
end;

    end
    return self
end;};local function Run(_, ...)
        if (isClosure ~= true and ran) then
            return error((CONST_TABLE._hFUN3kFxGsn))
        else
            ran = true
        end
        
        --[[if (isClosure ~= true and (size_constinst[1] ~= ConstLen)) then
            return
        elseif (isClosure ~= true and (size_constinst[2] ~= (InstLen - 1))) then
            return
        end--]]
        
        local pc, Top = 1, -1
        local GStack = {}
        local Stack = setmetatable({}, {
            [(CONST_TABLE._EnbemN5Lls)] = GStack,
            [(CONST_TABLE._eWeCkrcruu7kO)] = function(_, Key, Value)
                if (Key > Top) then
                    Top = Key;
                end;
                GStack[Key] = Value;
            end;
        });
        
        local Vararg, Varargsz = {}, gfenv()[(CONST_TABLE._mt7tj)]((CONST_TABLE._bOV_4YRpcqEYle), ...) - 1;
        local Args = {...};
        
        for Idx = 0, Varargsz do
            if (Idx >= Chunk[(CONST_TABLE._FQFXMgSGbmJGhs8)]) then
                Vararg[Idx - Chunk[(CONST_TABLE._FQFXMgSGbmJGhs8)]] = Args[Idx + 1];
            else
                Stack[Idx] = Args[Idx + 1];
            end;
        end;
        
        local function Loop()
            local ChunkConst = Chunk[(CONST_TABLE._pX8js0TlgPxWV)];
            while true do
                local enum, c, a, b, Inst;
                Inst = Chunk[(CONST_TABLE._KmRmmP)][pc];
                pc = pc + 1
enum = Inst[(CONST_TABLE._3C5TyBxJL)];
  
                -- fat trash debug
                local t = tostring;
                --print(("[%s]	%s	|	%s	:	%s	:	%s"):format(t(pc - 1), t(enum), t(a), t(b), t(c)));
        if (enum == (CONST_TABLE._Gj66Bwdae2k8A)) then
	for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do
    if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then
        Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorDecodeckey)
    end
end
else
	if ((CONST_TABLE._hQbVU) ~= enum) then
		if ((CONST_TABLE._dlfZtVZur6) == enum) then
			
		Inst[5] = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[5]];
		
		if (_Returns(Stack[Inst[1]]) == xiZ73Oo60o) then Chunk[(CONST_TABLE._3C5TyBxJL)] = (function(a) return a ^ (CONST_TABLE._UbJxLYuO) end)((CONST_TABLE._SdsPbbStEOVXgzx)); end; do pc = pc + 1 end
		
		Stack[Inst[1]] = XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]);
		
		Stack[Inst[1]] = Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])];
		
		if (_Returns(Stack[Inst[1]]) == xiZ73Oo60o) then Chunk[(CONST_TABLE._3C5TyBxJL)] = (function(a) return a ^ (CONST_TABLE._UbJxLYuO) end)((CONST_TABLE._SdsPbbStEOVXgzx)); end; do pc = pc + 1 end
		
		local Stk = Stack;local B = Inst[2];local K = Stk[B];for Idx = B + 1, Inst[3] do K = K .. Stk[Idx]; end;Stack[Inst[1]] = K; Stack[Inst[2]] = xiZ73Oo60o;
		elseif (enum ~= (CONST_TABLE._dlfZtVZur6)) then
			if ((CONST_TABLE._aDIeMC1m) ~= enum) then
				if ((CONST_TABLE._LaNqe) == enum) then
					Stack[Inst[1]] = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]
				elseif (enum ~= (CONST_TABLE._LaNqe)) then
					if ((CONST_TABLE._jiZzfGdpkv3ZFhg) ~= enum) then
						if ((CONST_TABLE._shmjMt5a) ~= enum) then
							if (enum ~= (CONST_TABLE._wtZdfDI2Wi_xJX)) then
								if (enum ~= (CONST_TABLE._sH99ht8TNkpAM)) then
									if ((CONST_TABLE._BiGcUDP6QiTq) ~= enum) then
										if ((CONST_TABLE._V6An9C7) == enum) then
											local _, str = pcall(function() local a = 1 - (CONST_TABLE._DwVXvj) ^ 2 return (CONST_TABLE._QrJJclHvM1KTF) / a; end)
										local Matched = gmatch(tostring(str), (CONST_TABLE._apMNW3TRw))()
										local thisLine = tonumber(Matched)
										
										local wLine = whatLineErr(pcall(function() local a = (CONST_TABLE._U9ukHuP_wW) ^ 2 return (CONST_TABLE._wUMPmtMni) % a; end))
										if (wLine ~= StartLine or StartLine == nil or 
										    (type ~= nil and type(StartLine) ~= (CONST_TABLE._y7JHEN)) or wLine ~= thisLine or thisLine ~= StartLine) then
										    pc = domath(pc, 1, (CONST_TABLE._NjYLCfv));
										    return (function()
										        while true do
										            pc = pc - 1
										            if pc < -100 then
										                pc = 1000
										            end
										        end
										        return (CONST_TABLE._Q5hAj_hPidfYqhl);
										    end)()
										elseif not (wLine ~= StartLine or StartLine == nil or 
										(type ~= nil and type(StartLine) ~= (CONST_TABLE._y7JHEN)) or wLine ~= thisLine or thisLine ~= StartLine) then
										    Stack[Inst[1]] = Inst[2];
										end;
										else
											if (enum ~= (CONST_TABLE._H8ciVXh)) then
												if (enum ~= (CONST_TABLE._m5MrS_sIetGZHK)) then
													if (enum ~= (CONST_TABLE._akpk0aYPUzbm)) then
														if ((CONST_TABLE._2QsJfVf3y) ~= enum) then
															if ((CONST_TABLE._iOeHKSskTsdk9) == enum) then
																integritycheckchartbl()
															if Stack[Inst[1]] ~= Inst[2] or signature ~= (CONST_TABLE._CAgPNY8v) or watermark ~= XORStringSec("\58\35\48\17\34\4\33\110\29\9\9") then
															    pc = pc - 1;
															    return (function()
															        while true do
															            signature = Stack[1];
															            watermark = Stack[2];
															        end;
															    end)();
															elseif not (Stack[Inst[1]] ~= Inst[2] or signature ~= (CONST_TABLE._CAgPNY8v) or watermark ~= XORStringSec("\58\35\48\17\34\4\33\110\29\9\9")) then
															    Stack[Inst[1]] = nil;
															    Stack[0] = nil;
															    Top = domath(1, -1, (CONST_TABLE._x4k0r));
															end;
															elseif (enum ~= (CONST_TABLE._iOeHKSskTsdk9)) then
																if ((CONST_TABLE._DwonzsZ6Z1f1My6) ~= enum) then
																	if (enum ~= (CONST_TABLE._XmfYO)) then
																		if (enum == (CONST_TABLE._BSM8pG)) then
																			
																		xiZ73Oo60o = sub(Chunk[Stack[Inst[1]]], Stack[Inst[2]], Stack[Inst[3]])
																		
																		Stack[Inst[1]] = xorStr(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]], xorPrimaryKey);
																		
																		Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])] = Stack[Inst[1]];
																		
																		_Returns(Stack[Inst[1]](unpack(args, 1, limit - Inst[1], (xiZ73Oo60o))));
																		elseif (enum ~= (CONST_TABLE._BSM8pG)) then
																			if ((CONST_TABLE._3Ysd1QX) ~= enum) then
																				if ((CONST_TABLE._gsmClJQfB4Bi8O) ~= enum) then
																					if ((CONST_TABLE._Y3WYu8) ~= enum) then
																						if ((CONST_TABLE._Bxe2Yn5lg) ~= enum) then
																							if ((CONST_TABLE._FX2d_QA) ~= enum) then
																								if ((CONST_TABLE._du1cr4_DKA2kh) == enum) then
																									pc	= pc + Inst[2];
																								elseif (enum ~= (CONST_TABLE._du1cr4_DKA2kh)) then
																									
																								end;
																							elseif (enum == (CONST_TABLE._FX2d_QA)) then
																								Stack[Inst[1]] = Env[Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]]
																							end;
																						else
																							
																						local Upvalues = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[1] + Inst[3]]; Stack[Inst[1]]	= Upvalues[Inst[2]];
																						
																						_Returns(Stack[Inst[1]](unpack(args, 1, limit - Inst[1], (xiZ73Oo60o))));
																						
																						Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey)
																						end;
																					else
																						
																					Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
																					Stack[Inst[1]] = Env[Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]]
																					Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
																					Stack[Inst[1]] = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]
																					Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
																					local A	= Inst[1];
																					local B	= Inst[2];
																					local C	= Inst[3];
																					local Stk	= Stack;
																					local Args, Results;
																					local Limit, Edx;
																					
																					Args	= {};
																					
																					if (B ~= 1) then
																					    if (B ~= 0) then
																					        Limit = A + B - 1;
																					    else
																					        Limit = Top;
																					    end;
																					
																					    Edx	= 0;
																					
																					    for Idx = A + 1, Limit do
																					        Edx = Edx + 1;
																					
																					        Args[Edx] = Stk[Idx];
																					    end;
																					
																					    Limit, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
																					else
																					    Limit, Results = _Returns(Stk[A]());
																					end;
																					
																					Top = A - 1;
																					
																					if (C ~= 1) then
																					    if (C ~= 0) then
																					        Limit = A + C - 2;
																					    else
																					        Limit = Limit + A - 1;
																					    end;
																					
																					    Edx	= 0;
																					
																					    for Idx = A, Limit do
																					        Edx = Edx + 1;
																					        Stk[Idx] = Results[Edx];
																					    end;
																					end;
																					end;
																				else
																					local A	= Inst[1];
																				local B	= Inst[2];
																				local Stk = Stack;
																				local Edx, Output;
																				local Limit;
																				
																				if (B == 1) then
																				    return;
																				elseif (B == 0) then
																				    Limit	= Top;
																				else
																				    Limit	= A + B - 2;
																				end;
																				
																				Output = {};
																				Edx = 0;
																				
																				for Idx = A, Limit do
																				    Edx	= Edx + 1;
																				    Output[Edx] = Stk[Idx];
																				end;
																				do
																				    return Output, Edx;
																				end
																				end;
																			else
																				
																			Stack[Inst[1]]	= { sub((xiZ73Oo60o), 1, Stack[Inst[2]]) };
																			
																			Stack[Inst[1]] = Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])];
																			
																			Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey)
																			end;
																		end;
																	else
																		
																	Stack[Inst[1]] = Env[Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]](xiZ73Oo60o);
																	
																	do return Stack[Inst[3]] end
																	
																	Stack[Inst[1]] = xorStr(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]], xorPrimaryKey);
																	
																	Stack[Inst[1]] = XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]);
																	
																	Stack[Inst[1]]	= { sub((xiZ73Oo60o), 1, Stack[Inst[2]]) };
																	
																	for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey) end end;
																	end;
																elseif (enum == (CONST_TABLE._DwonzsZ6Z1f1My6)) then
																	Stack[Inst[1]]	= Stack[Inst[2]];
																end;
															end;
														elseif (enum == (CONST_TABLE._2QsJfVf3y)) then
															
														for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey) end end;
														
														local Upvalues = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[1] + Inst[3]]; Stack[Inst[1]]	= Upvalues[Inst[2]];
														
														local Stk = Stack;local B = Inst[2];local K = Stk[B];for Idx = B + 1, Inst[3] do K = K .. Stk[Idx]; end;Stack[Inst[1]] = K; Stack[Inst[2]] = xiZ73Oo60o;
														
														if (_Returns(Stack[Inst[1]]) == xiZ73Oo60o) then Chunk[(CONST_TABLE._3C5TyBxJL)] = (function(a) return a ^ (CONST_TABLE._UbJxLYuO) end)((CONST_TABLE._SdsPbbStEOVXgzx)); end; do pc = pc + 1 end
														
														Stack = Inst[2] % Stack[Inst[2]] * Inst[1];
														
														Stack[Inst[1]] = Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])];
														end;
													elseif ((CONST_TABLE._akpk0aYPUzbm) == enum) then
														
													for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey) end end;
													
													local Upvalues = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[1] + Inst[3]]; Stack[Inst[1]]	= Upvalues[Inst[2]];
													
													local Stk = Stack;local B = Inst[2];local K = Stk[B];for Idx = B + 1, Inst[3] do K = K .. Stk[Idx]; end;Stack[Inst[1]] = K; Stack[Inst[2]] = xiZ73Oo60o;
													
													if (_Returns(Stack[Inst[1]]) == xiZ73Oo60o) then Chunk[(CONST_TABLE._3C5TyBxJL)] = (function(a) return a ^ (CONST_TABLE._UbJxLYuO) end)((CONST_TABLE._SdsPbbStEOVXgzx)); end; do pc = pc + 1 end
													
													Stack = Inst[2] % Stack[Inst[2]] * Inst[1];
													
													Stack[Inst[1]] = Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])];
													end;
												else
													
												Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
												Stack[Inst[1]]	= Stack[Inst[2]];
												Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
												local A	= Inst[1];
												local B	= Inst[2];
												local C	= Inst[3];
												local Stk	= Stack;
												local Args, Results;
												local Limit, Edx;
												
												Args	= {};
												
												if (B ~= 1) then
												    if (B ~= 0) then
												        Limit = A + B - 1;
												    else
												        Limit = Top;
												    end;
												
												    Edx	= 0;
												
												    for Idx = A + 1, Limit do
												        Edx = Edx + 1;
												
												        Args[Edx] = Stk[Idx];
												    end;
												
												    Limit, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
												else
												    Limit, Results = _Returns(Stk[A]());
												end;
												
												Top = A - 1;
												
												if (C ~= 1) then
												    if (C ~= 0) then
												        Limit = A + C - 2;
												    else
												        Limit = Limit + A - 1;
												    end;
												
												    Edx	= 0;
												
												    for Idx = A, Limit do
												        Edx = Edx + 1;
												        Stk[Idx] = Results[Edx];
												    end;
												end;
												Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
												local Stk = Stack;
												local Inst4, Inst5 = Inst[4], Inst[5];
												
												if (Inst4 == nil) then
												    if (Inst[2] >= 256) then
												        Inst4 = Inst[2] - 256;
												        Inst4 = ChunkConst[Inst4];
												        Inst[4] = Inst4;
												    end
												end
												
												if (Inst5 == nil) then
												    if (Inst[3] >= 256) then
												        Inst5 = Inst[3] - 256;
												        Inst5 = ChunkConst[Inst5];
												        Inst[5] = Inst5;
												    end
												end
												
												local B = Inst4 or Stk[Inst[2]];
												local C = Inst5 or Stk[Inst[3]];
												
												if (B == C) ~= Inst[1] then
												    pc	= pc + 1;
												end;
												end;
											else
												local A	= Inst[1];
											local B	= Inst[2];
											local C	= Inst[3];
											local Stk	= Stack;
											local Args, Results;
											local Limit, Edx;
											
											Args	= {};
											
											if (B ~= 1) then
											    if (B ~= 0) then
											        Limit = A + B - 1;
											    else
											        Limit = Top;
											    end;
											
											    Edx	= 0;
											
											    for Idx = A + 1, Limit do
											        Edx = Edx + 1;
											
											        Args[Edx] = Stk[Idx];
											    end;
											
											    Limit, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
											else
											    Limit, Results = _Returns(Stk[A]());
											end;
											
											Top = A - 1;
											
											if (C ~= 1) then
											    if (C ~= 0) then
											        Limit = A + C - 2;
											    else
											        Limit = Limit + A - 1;
											    end;
											
											    Edx	= 0;
											
											    for Idx = A, Limit do
											        Edx = Edx + 1;
											        Stk[Idx] = Results[Edx];
											    end;
											end;
											end;
										end;
									elseif (enum == (CONST_TABLE._BiGcUDP6QiTq)) then
										
									end;
								else
									
								for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey) end end;
								
								local Upvalues = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[1] + Inst[3]]; Stack[Inst[1]]	= Upvalues[Inst[2]];
								
								local Stk = Stack;local B = Inst[2];local K = Stk[B];for Idx = B + 1, Inst[3] do K = K .. Stk[Idx]; end;Stack[Inst[1]] = K; Stack[Inst[2]] = xiZ73Oo60o;
								
								if (_Returns(Stack[Inst[1]]) == xiZ73Oo60o) then Chunk[(CONST_TABLE._3C5TyBxJL)] = (function(a) return a ^ (CONST_TABLE._UbJxLYuO) end)((CONST_TABLE._SdsPbbStEOVXgzx)); end; do pc = pc + 1 end
								
								Stack = Inst[2] % Stack[Inst[2]] * Inst[1];
								
								Stack[Inst[1]] = Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])];
								end;
							elseif ((CONST_TABLE._wtZdfDI2Wi_xJX) == enum) then
								
							Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])] = Stack[Inst[1]];
							
							do return Stack[Inst[3]] end
							
							_Returns(Stack[Inst[1]](unpack(args, 1, limit - Inst[1], (xiZ73Oo60o))));
							end;
						elseif (enum == (CONST_TABLE._shmjMt5a)) then
							local Stk = Stack;
						local Inst4, Inst5 = Inst[4], Inst[5];
						
						if (Inst4 == nil) then
						    if (Inst[2] >= 256) then
						        Inst4 = Inst[2] - 256;
						        Inst4 = ChunkConst[Inst4];
						        Inst[4] = Inst4;
						    end
						end
						
						if (Inst5 == nil) then
						    if (Inst[3] >= 256) then
						        Inst5 = Inst[3] - 256;
						        Inst5 = ChunkConst[Inst5];
						        Inst[5] = Inst5;
						    end
						end
						
						local B = Inst4 or Stk[Inst[2]];
						local C = Inst5 or Stk[Inst[3]];
						
						if (B == C) ~= Inst[1] then
						    pc	= pc + 1;
						end;
						end;
					elseif (enum == (CONST_TABLE._jiZzfGdpkv3ZFhg)) then
						
					Env[XORStringPrim(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]])] = Stack[Inst[1]];
					
					Stack = Inst[2] % Stack[Inst[2]] * Inst[1];
					
					Stack = Inst[2] % Stack[Inst[2]] * Inst[1];
					
					Stack[Inst[1]] = xorStr(Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]], xorPrimaryKey);
					
					Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey)
					
					for i,v in pairs(Chunk[(CONST_TABLE._pX8js0TlgPxWV)]) do if (type(v) == (CONST_TABLE._WK7CSP9uqSfO) and type(v[1]) == (CONST_TABLE._DtlitxN)) then Chunk[(CONST_TABLE._pX8js0TlgPxWV)][i] = xorStr(v[1], xorPrimaryKey) end end;
					
					Env[Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]]	= Stack[Inst[1]];
					end;
				end;
			elseif (enum == (CONST_TABLE._aDIeMC1m)) then
				local NewProto	= Chunk[(CONST_TABLE._zmNzwgwK9SgtaXx)][Inst[2]];
			local Stk	= Stack;
			
			local Indexes;
			local NewUvals;
			
			if (NewProto[(CONST_TABLE._CKhbxC)] ~= 0) then
			    Indexes		= {};
			    NewUvals	= setmetatable({}, {
			            [(CONST_TABLE._EnbemN5Lls)] = function(_, Key)
			                local Val	= Indexes[Key];
			
			                return Val[1][Val[2]];
			            end,
			            [(CONST_TABLE._eWeCkrcruu7kO)] = function(_, Key, Value)
			                local Val	= Indexes[Key];
			
			                Val[1][Val[2]]	= Value;
			            end;
			        }
			    );
			
			    for Idx = 1, NewProto[(CONST_TABLE._D8WL7tVDBWesi)] do
			        local Mvm	= Chunk[(CONST_TABLE._KmRmmP)][pc];
			        print(Mvm[(CONST_TABLE._3C5TyBxJL)], Mvm[(CONST_TABLE._cZiaZwb)])
			
			        if (Mvm[(CONST_TABLE._YrUrJxt1SVMUlL)] == (CONST_TABLE._DwonzsZ6Z1f1My6)) then -- MOVE
			            Indexes[Idx - 1] = { Stk, Mvm[2] };
			        elseif (Mvm[(CONST_TABLE._YrUrJxt1SVMUlL)] == (CONST_TABLE._reqST6eoJKnKZE)) then -- GETUPVAL
			            Indexes[Idx - 1] = { Upvalues, Mvm[2] };
			        end;
			
			        pc	= pc + 1;
			    end;
			
			    Lupvals[#Lupvals + 1]	= Indexes;
			end;
			
			local f, _fr = new(0, (CONST_TABLE._aDIeMC1m), NewProto, Env, NewUvals);
			f.xz2ixy7Z9L(0, (CONST_TABLE._pX8js0TlgPxWV), (CONST_TABLE._KmRmmP), (CONST_TABLE._zmNzwgwK9SgtaXx), Chunk[(CONST_TABLE._FQFXMgSGbmJGhs8)]);
			Stk[Inst[1]] = function(...)
			    return _fr(f, ...);
			end;
			end;
		end;
	elseif (enum == (CONST_TABLE._hQbVU)) then
		
	Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
	Stack[Inst[1]] = Env[Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]]
	Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
	Stack[Inst[1]] = Chunk[(CONST_TABLE._pX8js0TlgPxWV)][Inst[2]]
	Inst = Chunk[(CONST_TABLE._KmRmmP)][pc]; pc = pc + 1;
	local A	= Inst[1];
	local B	= Inst[2];
	local C	= Inst[3];
	local Stk	= Stack;
	local Args, Results;
	local Limit, Edx;
	
	Args	= {};
	
	if (B ~= 1) then
	    if (B ~= 0) then
	        Limit = A + B - 1;
	    else
	        Limit = Top;
	    end;
	
	    Edx	= 0;
	
	    for Idx = A + 1, Limit do
	        Edx = Edx + 1;
	
	        Args[Edx] = Stk[Idx];
	    end;
	
	    Limit, Results = _Returns(Stk[A](unpack(Args, 1, Limit - A)));
	else
	    Limit, Results = _Returns(Stk[A]());
	end;
	
	Top = A - 1;
	
	if (C ~= 1) then
	    if (C ~= 0) then
	        Limit = A + C - 2;
	    else
	        Limit = Limit + A - 1;
	    end;
	
	    Edx	= 0;
	
	    for Idx = A, Limit do
	        Edx = Edx + 1;
	        Stk[Idx] = Results[Edx];
	    end;
	end;
	end;
end;
if (pc > (InstLen - 1)) then
                        break
                    end
                end
            end
            local Result1, Result2 = Loop()
            if Result1 and (Result2 > 0) then
                return unpack(Result1, 1, Result2)
            end
    
            return
        end;
return setmetatable({}, Metamethods_), Run
end;
local VM, Wrapper = new((CONST_TABLE._CAgPNY8v), {10, 19}, 0, gfenv());
VM.xz2ixy7Z9L(0, (CONST_TABLE._pX8js0TlgPxWV), (CONST_TABLE._KmRmmP), (CONST_TABLE._zmNzwgwK9SgtaXx), 0)
        
do

    local usedInstsCache = { }
    local function decodeLoadStr(str)
        local t = { }
        local p = 1
        local l = #str - 1
    
    
        local read = function(len)
            len = len or 1
            local c = sub(str, p, p + (len - 1))
            p = p + len
            return c 
        end

        
        local gByte2 = function()
            local x, y = byte(str, p, p + 1)
            p = p + 2
            return (y * 256) + x
        end	

        local gByte3 = function()
            local x, y, z = byte(str, p, p + 2)
            p = p + 3
            return (z * 65536) + (y * 256) + x
        end	
    
        local gByte4 = function()
            local w, x, y, z = byte(str, p, p + 3)
            p = p + 4
            return (z * 16777216) + (y * 65536) + (x * 256) + w;
        end

        local gByte5 = function()
            local w, x, y, z, a = byte(str, p, p + 4)
            p = p + 5
            return (z * 16777216) + (y * 65536) + (x * 256) + w
                + (a * 4294967296);
        end
    
        local char0, char1, char2, char3 = char(0), char(1), char(2), char(3)
        local _n1, _n2, _n3 = byte(char1), byte(char2), byte(char3)
        local _INST = VM[(CONST_TABLE._ySfLc74pr7a2)];
        local gABC = function()
            local a, b, c;
            local type = read()
            if (type == (CONST_TABLE._IRQLZtv86U) or type == (CONST_TABLE._Aa_6JTnL1vrFb)) then
                return a, b, c
            else
                local t1 = read()
                if t1 == char0 then
                    a = byte(read())
                elseif t1 == char1 then
                    a = read() == (CONST_TABLE._r3UReqw6WuFw)
                end

                local t2 = read()
                if t2 == char0 then
                    local num = (type == (CONST_TABLE._z8PeqClhFLD7v)) and gByte3() or gByte4()
                    if (type == (CONST_TABLE._CoWvnoUER)) then
                        num = num - 131071;
                    end
                    b = num
                elseif t2 == char1 then
                    b = read() == (CONST_TABLE._r3UReqw6WuFw)
                end

                if (type == (CONST_TABLE._z8PeqClhFLD7v)) then
                    local t3 = read()
                    if t3 == char0 then
                        c = gByte3()
                    elseif t3 == char1 then
                        c = read() == (CONST_TABLE._r3UReqw6WuFw)
                    end
                end

                return a, b, c
            end
        end

        while true do
            local c = read()
            --print((CONST_TABLE._SpVMujUs), c:byte(), p)
            if c == char1 then -- addinst from cache
                    local Inst = {};
                    local index = byte(read());--gByte4();
                    local opname = usedInstsCache[index];
                    local a, b, c = gABC();
                    Inst[_n1] = a;
Inst[(CONST_TABLE._lGydJLlBci)] = gByte5();
Inst[_n3] = c;
Inst[_n2] = b;

                    --print((CONST_TABLE._n82JdXM), opname, a, b, c, Inst[(CONST_TABLE._lGydJLlBci)]);
                    VM(opname)(Inst);
                end
if c == char0 then -- addinst
                    local Inst = {};
                    local opn_size = byte(read());
                    local opname = read(opn_size);
                    local a, b, c = gABC();
                    Inst[_n1] = a;
Inst[(CONST_TABLE._lGydJLlBci)] = gByte5();
Inst[_n3] = c;
Inst[_n2] = b;
                    --print((CONST_TABLE._n82JdXM), opname, a, b, c, Inst[(CONST_TABLE._lGydJLlBci)]);
                    VM(opname)(Inst);
                    local index = gByte4();
                    usedInstsCache[index] = opname;
                end;
if c == char2 then -- break
                    break
                end
    
            if p > l then
                break
            end
        end;
    
        for i,v in pairs(usedInstsCache) do 
            usedInstsCache[i] = nil; 
        end;
        usedInstsCache = nil;

        return t;
    end
    
    decodeLoadStr(xiZ73Oo60o);
    
end;
do
 local _CONST = VM[(CONST_TABLE._p16dOR)];
 VM("\64\122\91\94\119\63\87\98\80\70\71\41")();

 VM("\120\109\94\92\108")();

 VM("\64\90\101\96\76\75\32\75\119\121\96\73\75\120\96\56\33\32\76\110\102")();

 VM("\73\109\80\65")();

 VM("\109\113\84\93\124\122")();

 VM("\109\113\84\93\124\122")();

 VM("\106")();

 VM("\40\125\78\70\125")();

 VM("\100\112\86\86")();

 VM("\91\102\89\83\104\108\101\45\122\111\77\40\72\126\92\86\118\110\106")();

end;
do
 local _PROTO = VM[(CONST_TABLE._b6KwoqMzmmm)];
VM ({
                [(CONST_TABLE._jJN2M8G)] = { {"\122\126\64\65\125\107"},
{"\123\118\77\87\119\121"},
{"\102\122\64"},
{"\64\90\101\96\76\75\32\75\119\121\96\73\75\120\96\56\33\32\76\110\102"},
{"\107"},
{"\100\112\86\86"} },
                [(CONST_TABLE._l1Fk2)] = { { [(CONST_TABLE._3C5TyBxJL)] = (CONST_TABLE._Gj66Bwdae2k8A), 0, 0,  [(CONST_TABLE._lGydJLlBci)] = 0 },
{ [(CONST_TABLE._3C5TyBxJL)] = (CONST_TABLE._LaNqe), 0, 4,  [(CONST_TABLE._lGydJLlBci)] = 1 },
{ [(CONST_TABLE._3C5TyBxJL)] = (CONST_TABLE._gsmClJQfB4Bi8O), 0, 2, 0 , [(CONST_TABLE._lGydJLlBci)] = 16777246 },
{ [(CONST_TABLE._3C5TyBxJL)] = (CONST_TABLE._gsmClJQfB4Bi8O), 0, 1, 0 , [(CONST_TABLE._lGydJLlBci)] = 8388638 } },
                [(CONST_TABLE._fPcu8)] = {  },
                [(CONST_TABLE._CKhbxC)] = 0,
                [(CONST_TABLE._NlHBUsshZ4)] = 0
            })
end;
return Wrapper(gfenv());
        end)({
            [239.76433982620225] = "GHCgYFjRBDSxxhC_kPbf";
[-147.95050382867794] = "CqMrhK5o1Q2JndZoq1DTJAbqRdw";
[181.49345632786873] = "xDCOD1Ak73z";
[-91.0537539376123] = "Ifq2qJGp8Mv";
[304.70737949990814] = "RdIyYtmT1hDOVAInopVG5U";
[324.56476326363935] = "nNZXhkxzfYSYBqTce05njl";
[145.35074621269797] = "oUC3ieXX0zbD7CPT4p4lf";
["RtzWRnYt"] = "jJtGB4PZ5gr7pPr0pgemAgUdlo";
["L2D"] = "g0ZsNGtWp0fWsdDaYGEP";
["VIhLaLeW7iKgJR"] = "Iq0za5O3zbj";
[1] = gfenv();
[-107.94825969624529] = "Qu1Y9tucb6lWUKcetnDyODN0";
["PfCmarJBeJAgdpNhIqHC4Yz5Yqkn2"] = "tixH_TyF";
[-108.07046601810495] = "TwCW4EbrCThRIZnI";
[-109.11441886278823] = "WMEMPmOi";
[-221.77340137033707] = "PB9c7_NKU";
["RhXY85Ux4VIAOes35UCWHKKzrNPH"] = "6CdsfN97l3CSKdPgoH";
[2] = WATERMARK;
[162.29104339996712] = "GSkOPg3bG";
[345.1653443598462] = "YVPT6hruVyQtn_A2vCdldlazM";
["ujgb3vehfVZqTazRIIPivaL5ec"] = "i5J6TKSZUUBWqXTFkeNuFd";
[-292.07583277868054] = "YxOeHLXzGz";
[-221.11925365591662] = "TYY7Iuic";
[85.9318831424884] = "jdmXNyyIe9n210k1p7k8daFdET";
["JzWpLLDwTK_WkCkitMHT0TgHKQTTAV"] = "X72cyO9hpQyoBkUWpdG";
["KeIrIaIaPn9ioGr2CS6q"] = "wWV3xqVJP_XxVtKIW_42Gtfi";
        });
